<template>
  <div class="partner">
    <Partnerpage />
  </div>
</template>

<script>
// @ is an alias to /src
import Partnerpage from "@/components/Partnerpage.vue";

export default {
  name: "partner",
  components: {
    Partnerpage
  }
};
</script>
