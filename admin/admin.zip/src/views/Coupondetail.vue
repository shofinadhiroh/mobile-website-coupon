<template>
  <div class="coupondetail">
    <Coupondetail />
  </div>
</template>

<script>
// @ is an alias to /src
import Coupondetail from "@/components/Coupondetailpage.vue";

export default {
  name: "coupondetail",
  components: {
    Coupondetail
  }
};
</script>
