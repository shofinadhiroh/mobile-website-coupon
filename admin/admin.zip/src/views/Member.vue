<template>
  <div>
    <Member />
  </div>
</template>

<script>
// @ is an alias to /src
import Member from "@/components/Memberpage.vue";

export default {
  name: 'member',
  components: {
    Member
  },
};
</script>
