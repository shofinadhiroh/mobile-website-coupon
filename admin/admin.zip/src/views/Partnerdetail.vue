<template>
  <div class="partnerdetail">
    <Partnerdetail />
  </div>
</template>

<script>
// @ is an alias to /src
import Partnerdetail from "@/components/Partnerdetailpage.vue";

export default {
  name: "partnerdetail",
  components: {
    Partnerdetail
  }
};
</script>
