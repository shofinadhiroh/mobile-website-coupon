<template>
  <div class="paymentcode">
    <Payment />
  </div>
</template>

<script>
// @ is an alias to /src
import Payment from "@/components/Paymentcodepage.vue";

export default {
  name: "paymentcode",
  components: {
    Payment
  }
};
</script>
