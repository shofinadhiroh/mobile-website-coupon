<template>
  <div>
    <Payment />
  </div>
</template>

<script>
// @ is an alias to /src
import Payment from "@/components/Notificationpage.vue";

export default {
  name: 'payment',
  components: {
    Payment
  },
};
</script>
